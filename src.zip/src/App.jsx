import { Route, Routes } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import StudentDashboard from './Student/StudentDashboard';
import MyEvents from './Student/MyEvents';
import SuperAdminDashboard from './SuperAdmin/SuperAdmindashboard';
import Main from './Home/main';
import Navbar from './Home/navbar';
import DomeGallery from './Home/globe/DomeGallery';
import AdminRoutes from './Admin/AdminRoutes';
import Events from './Events/components/Events';
import EventDetails from './Events/components/EventDetails';
import Clubs from './Home/Bodies/clubs';
import './Home/HomePage.css';

function Home() {
  return (
    <>
      <Navbar />
      <div className="home-page">
        <Main />
        <DomeGallery />
        <Clubs />
      </div>
    </>
  );
}

function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/admin/*" element={
          <ProtectedRoute allowedRoles={['admin', 'superadmin']}>
            <AdminRoutes />
          </ProtectedRoute>
        } />
        <Route path="/student/dashboard" element={
          <ProtectedRoute allowedRoles={['student']}>
            <StudentDashboard />
          </ProtectedRoute>
        } />
        <Route path="/student/my-events" element={
          <ProtectedRoute allowedRoles={['student']}>
            <MyEvents />
          </ProtectedRoute>
        } />
        <Route path="/superadmin" element={
          <ProtectedRoute allowedRoles={['superadmin']}>
            <SuperAdminDashboard />
          </ProtectedRoute>
        } />
        <Route path="/events" element={<Events />} />
        <Route path="/events/:id" element={<EventDetails />} />
      </Routes>
    </AuthProvider>
  );
}

export default App;
